            <?php wp_footer(); ?>
        </div> <!-- fin #main -->
    </div> <!-- fin #page -->
</body>