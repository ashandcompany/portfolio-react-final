<?php
get_header(); // Chargement de l'en-tête

if (have_posts()) :
    while (have_posts()) : the_post();
?>
<div class="personnage-detail">
    <h1><?php the_title(); ?></h1>

    <!-- Date de publication -->
    <div class="publication-date">
        Publié le <?php echo get_the_date(); ?>
    </div>

    <!-- Image principale -->
    <?php
    $image = get_field('image_du_personnage');
    if ($image) {
        echo '<div class="center">';
        echo '<img class="character-image" src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['alt']) . '">';
        echo '</div>';
    }
    ?>

    <!-- Description -->
    <div class="personnage-description">
        <?php the_content(); ?>
    </div>

    <!-- Image à la une -->
    <div class="personnage-image">
        <?php the_post_thumbnail(); ?>
    </div>

    <!-- Catégories -->
    <div class="personnage-categories">
        <?php the_terms(get_the_ID(), 'categories_personnages'); ?>
    </div>

    <!-- Tags -->
    <div class="personnage-tags">
        <?php
        $fields = [
            'Surnoms' => get_field('surnoms'),
            'Né à' => get_field('ne_a'),
            'Genre' => get_field('genre'),
            'Première apparence' => get_field('premiere_apparence')
        ];

        foreach ($fields as $label => $value) {
            if ($value) {
                echo '<span class="tag"><strong>' . esc_html($label) . '</strong>: ' . esc_html($value) . '</span>';
            }
        }

        $mort = get_field('mort') ? 'Oui' : 'Non';
        echo '<span class="tag"><strong>Mort</strong>: ' . esc_html($mort) . '</span>';
        ?>
    </div>
</div>
<?php
    endwhile;
endif;

get_footer(); // Chargement du pied de page
?>
