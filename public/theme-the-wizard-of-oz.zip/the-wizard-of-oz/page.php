<?php get_header(); ?>
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
            <?php the_content(); ?>
		</div>
	</div>
<?php get_footer(); ?>