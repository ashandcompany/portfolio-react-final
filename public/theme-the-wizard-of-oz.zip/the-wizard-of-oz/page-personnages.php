<?php
/*
Template Name: Personnages
*/
get_header();  // Charge l'en-tête du site

// La boucle WordPress pour afficher les personnages
$args = array(
    'post_type' => 'personnages', // Assurez-vous que 'personnages' est le bon type de publication
    'posts_per_page' => -1, // Affiche tous les personnages
);

$query = new WP_Query($args);

if ($query->have_posts()) :
    echo '<div class="personnages-list">';
    echo "Ce fichier est page-personnages.php";

    while ($query->have_posts()) : $query->the_post();
        ?>
        <div class="personnage-item">
            <h2><?php the_title(); ?></h2>
            <div class="personnage-thumbnail">
                <?php the_post_thumbnail('medium'); ?> <!-- Affiche l'image à la une -->
            </div>
            <div class="personnage-excerpt">
                <?php
                // Tronquer le contenu à 3 lignes
                $content = get_the_content();
                echo wp_trim_words($content, 20, '...'); // Ajustez le nombre de mots ici
                ?>
            </div>
            <a href="<?php the_permalink(); ?>" class="read-more">Lire plus</a> <!-- Lien vers la page de détail -->
        </div>
        <?php
    endwhile;
    echo '</div>';
else :
    echo '<p>Aucun personnage trouvé.</p>';
endif;

wp_reset_postdata();  // Réinitialise les données de la requête

get_footer();  // Charge le pied de page du site
