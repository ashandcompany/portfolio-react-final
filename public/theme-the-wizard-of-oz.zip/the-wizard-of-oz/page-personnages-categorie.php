<?php
/*
Template Name: Personnages par catégorie
*/
get_header();  // Charge l'en-tête du site

// Récupérer l'ID de la catégorie depuis l'URL (assurez-vous que l'URL contient le bon slug de la catégorie)
$category_slug = get_query_var('category_name'); // Cela récupère le slug de la catégorie à partir de l'URL

// Obtenir l'ID de la catégorie
$category = get_category_by_slug($category_slug);
$category_id = $category ? $category->term_id : 0;

// La boucle WordPress pour afficher les personnages dans cette catégorie
$args = array(
    'post_type' => 'personnages', // Assurez-vous que 'personnages' est le bon type de publication
    'posts_per_page' => -1, // Affiche tous les personnages
    'tax_query' => array(
        array(
            'taxonomy' => 'category', // La taxonomie par défaut
            'field' => 'id',
            'terms' => $category_id,
            'operator' => 'IN',
        ),
    ),
);

$query = new WP_Query($args);

if ($query->have_posts()) :
    echo '<div class="personnages-list">';

    while ($query->have_posts()) : $query->the_post();
        ?>
        <div class="personnage-item">
            <h2><?php the_title(); ?></h2>
            <div class="personnage-thumbnail">
                <?php the_post_thumbnail('medium'); ?> <!-- Affiche l'image à la une -->
            </div>
            <div class="personnage-excerpt">
                <?php
                // Tronquer le contenu à 3 lignes
                $content = get_the_content();
                echo wp_trim_words($content, 20, '...'); // Ajustez le nombre de mots ici
                ?>
            </div>
            <a href="<?php the_permalink(); ?>" class="read-more">Lire plus</a> <!-- Lien vers la page de détail -->
        </div>
        <?php
    endwhile;
    echo '</div>';
else :
    echo '<p>Aucun personnage trouvé dans cette catégorie.</p>';
endif;

wp_reset_postdata();  // Réinitialise les données de la requête

get_footer();  // Charge le pied de page du site
