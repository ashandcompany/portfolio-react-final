<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<title><?php wp_title( '|', true, 'right' ); ?><?php bloginfo( 'name' ); ?></title>
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
    <link rel="preload" as="image" href="/background_2.webp" type="image/webp" />
	<?php wp_head(); ?>
</head>
<body <?php body_class( wp_is_mobile() ? 'mobile_friendly' : '' ); ?>>
	<?php wp_body_open(); ?>
	<div id="page" class="hfeed site">
		<header id="masthead" class="site-header">
        <div class="header-container">
    <a class="home-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
        <img src="<?= get_template_directory_uri(); ?>/assets/img/logo.svg" alt="<?php bloginfo( 'name' ); ?>" width="128" />
    </a>
    
    <!-- Ajout du bouton burger -->
    <button class="burger" id="burger-menu">
        <span></span>
        <span></span>
        <span></span>
    </button>

    <div id="navbar" class="navbar">
        <nav id="site-navigation" class="navigation main-navigation">
            <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'main',
                        'menu_class'     => 'menu',
                        'menu_id'        => 'menu',
                    )
                );
            ?>
        </nav>
    </div>
</div>

		</header>

        <script>
        // Ajout du script pour ouvrir et fermer le menu
document.getElementById('burger-menu').addEventListener('click', function () {
    this.classList.toggle('active');
    document.querySelector('#navbar .menu').classList.toggle('active');
});

    </script>
    
		<div id="main" class="site-main">