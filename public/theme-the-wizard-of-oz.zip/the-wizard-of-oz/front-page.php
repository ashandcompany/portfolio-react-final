<?php get_header(); ?>

<main id="content" role="main">
  <!-- Section principale -->
  <section class="hero">
    <div class="hero-content">
      <h1 class="highlighted-text-shadow">Bienvenue dans le monde du Magicien d'Oz</h1>
      <p>Explorez l'univers magique du Magicien d'Oz à travers des articles, des histoires et des analyses approfondies de cet univers fantastique.</p>
      <a href="#articles" class="btn-primary">Découvrir nos articles</a>
    </div>
  </section>

  <!-- Section des derniers articles -->
  <section id="articles" class="featured-posts">
    <h2>Les derniers articles</h2>

    <?php
      // Récupérer les 3 derniers articles
      $args = array(
        'post_type' => 'personnages',
        'posts_per_page' => 3, // Afficher 3 derniers articles
      );
      $recent_posts = new WP_Query($args);

      if ($recent_posts->have_posts()) : // Correction ici : $query -> $recent_posts
        echo '<div class="personnages-list">';
    
        while ($recent_posts->have_posts()) : $recent_posts->the_post(); // Ajout de the_post() pour que la boucle fonctionne
            ?>
            <div class="personnage-item">
                <h2><?php the_title(); ?></h2>
                <div class="personnage-thumbnail">
                    <?php the_post_thumbnail('medium'); ?> <!-- Affiche l'image à la une -->
                </div>
                <div class="personnage-excerpt">
                    <?php
                    // Tronquer le contenu à 3 lignes
                    $content = get_the_content();
                    echo wp_trim_words($content, 20, '...'); // Ajustez le nombre de mots ici
                    ?>
                </div>
                <a href="<?php the_permalink(); ?>" class="read-more">Lire plus</a> <!-- Lien vers la page de détail -->
            </div>
            <?php
        endwhile;
        echo '</div>';
        wp_reset_postdata(); // Réinitialiser les données après la boucle
    else :
        echo '<p>Aucun personnage trouvé.</p>';
    endif;
    ?>
  </section>
</main>

<?php get_footer(); ?>
