<?php
// Chargement des styles du thème parent et enfant
function theme_enfant_styles() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('child-style', get_stylesheet_uri(), array('parent-style'));
}
add_action('wp_enqueue_scripts', 'theme_enfant_styles');

function create_custom_post_type_oz() {
    $labels = array(
        'name' => 'Personnages',
        'singular_name' => 'Personnage',
        'add_new' => 'Ajouter un nouveau',
        'add_new_item' => 'Ajouter un nouveau personnage',
        'edit_item' => 'Modifier le personnage',
        'new_item' => 'Nouveau personnage',
        'view_item' => 'Voir le personnage',
        'all_items' => 'Tous les personnages',
        'search_items' => 'Rechercher un personnage',
        'not_found' => 'Aucun personnage trouvé',
        'not_found_in_trash' => 'Aucun personnage dans la corbeille'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'rewrite' => array('slug' => 'personnages'),
    );

    register_post_type('personnages', $args);
}
add_action('init', 'create_custom_post_type_oz');

function create_oz_taxonomies() {
    register_taxonomy(
        'categories_personnages',
        'personnages',
        array(
            'label' => 'Catégories de personnages',
            'rewrite' => array('slug' => 'categorie-personnages'),
            'hierarchical' => true,
            'show_in_nav_menus' => true,
        )
    );
}
add_action('init', 'create_oz_taxonomies');

function insert_adsense_banners($content) {

    global $post;
    $personnages = $post;   
    
    if (!is_singular(['post', 'personnages']) || !get_field('enable_adsense')) {
        return $content;
    }

    // Récupère le nombre de vues des publicités pour le personnage
    $views = get_field('adsense_views', $personnages->ID);

    // Crée le HTML pour la bannière publicitaire
    $ad_banner = '<div class="adsense-banner" style="text-align: center; margin: 20px 0;">
        <img src="' . get_stylesheet_directory_uri() . '/ad.webp" alt="Publicité">
    </div>';

    // Sépare le contenu à chaque <h2> et met chaque partie dans un tableau
    $parts = explode('<h2>', $content);

    // Si il n'y a pas ou qu'une seule balise <h2>, on ne modifie pas le contenu
    if (count($parts) <= 2) {
        return $content;
    }

    // On garde la première partie sans modification
    $content_with_ads = $parts[0];

    // On parcourt les parties restantes
    foreach (array_slice($parts, 1) as $index => $part) {
        // Ajoute une bannière avant chaque partie qui contient un <h2>
        if ($index > 0) {
            $content_with_ads .= $ad_banner;
        }
        // Ajoute chaque partie avec son <h2>
        $content_with_ads .= '<h2>' . $part;
    }

    // Incrémente le nombre de vues des publicités
    $views++;
    update_field('adsense_views', $views, $personnages->ID);

    // Ajoute l'affichage du nombre de vues de la publicité à la fin du contenu
    $content_with_ads .= '<hr style="margin-top: 3rem;"><div class="adsense-views" style="font-size: .8rem; margin: 20px 0; font-style: italic;">
    <p>Le nombre de vues de ces publicités : ' . $views . '</p>
    </div><hr>';

    return $content_with_ads;
}

// Applique le filtre pour insérer les bannières publicitaires dans le contenu
add_filter('the_content', 'insert_adsense_banners');

// function increment_cpt_views($post_id) {

//     if (get_post_type($post_id) == 'personnages' && !wp_is_post_revision($post_id)) {
//         $views = get_field('compteur_de_vues', $post_id);
//         if (!$views) {
//             $views = 0;
//         }
//         $views++;
//         update_field('compteur_de_vues', $views, $post_id);
//     }
// }

function my_plugin_add_admin_bar_items( $admin_bar ) {
    global $post;

    if ( is_singular(['post', 'personnages']) && isset( $post ) && get_post_type( $post->ID ) == 'personnages' ) {

        $views = get_field('compteur_de_vues', $post->ID);
        if ( !$views ) {
            $views = 1;
        }
        
        // Code SVG pour l'icône (vous pouvez le personnaliser)
        $svg_code = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="16" height="16" style="vertical-align: middle; margin-right: 5px;"><path fill="#FFFFFF" d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>';

        // Ajouter un élément dans la barre d'administration
        $admin_bar->add_menu(
            array(
                'id'    => 'my-plugin-menu',
                'title' => $svg_code . 'Vues hebdomadaires : ' . $views,
                'meta'  => array(
                    'class' => 'my-plugin-class',
                    'title' => 'Vues de l\'article : ' . $views,
                ),
            )
        );

        $views++;
        update_field('compteur_de_vues', $views, $post->ID);
    }
}
add_action( 'admin_bar_menu', 'my_plugin_add_admin_bar_items', 90 );

if (!wp_next_scheduled('reset_cpt_views_weekly')) {
    wp_schedule_event(strtotime('next Monday midnight'), 'weekly', 'reset_cpt_views_weekly');
}

function reset_personnages_views() {
    $args = array(
        'post_type' => 'personnages',
        'posts_per_page' => -1
    );

    $posts = get_posts($args);

    foreach ($posts as $post) {
        update_field('compteur_de_vues', 0, $post->ID);
    }
}

add_action('reset_cpt_views_weekly', 'reset_personnages_views');

?>